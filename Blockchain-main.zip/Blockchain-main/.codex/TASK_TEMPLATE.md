# Task
**Goal:** <what to build>

## Changes
- <files and reasons>

## Acceptance
- <explicit checks, curls, UI clicks>

## Out of scope
- <leave unrelated code untouched>
