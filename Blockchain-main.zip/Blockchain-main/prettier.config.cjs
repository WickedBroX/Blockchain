module.exports = {
  singleQuote: false,
  semi: true,
  trailingComma: "all",
  printWidth: 100,
  tabWidth: 2,
};
